nasm -f elf -o mult.o mult.asm
nasm -f elf -o maiorValorDiag.o maiorValorDiag.asm
gcc -m32 -o main.out main.c mult.o maiorValorDiag.o